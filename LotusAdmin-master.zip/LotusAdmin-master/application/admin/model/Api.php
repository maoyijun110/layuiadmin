<?php
namespace app\admin\model;
use think\Model;
class Api extends Model
{
	protected $autoWriteTimestamp = true;
}
