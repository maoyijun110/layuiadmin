* 演示站点：https://www.lotusadmin.top/ 
* 账号 ： admin
* 密码 ： 123456
 
官方交流群：606645328 
![mahua](./public/pic/step2.png)
![mahua](./public/pic/index.png)
![mahua](./public/pic/main3.png)
![mahua](./public/pic/desktop.png)
![mahua](./public/pic/main2.png)
##LotusAdmin是什么?

一个使用thinkphp5.0.11+layui2.0后台开发的极速开发框架

##向thinkphp致敬
* 基于layuui2.0+thinkphp5.0

##LotusAdmin有哪些功能？
* 极简--极简和响应式的高颜值响应式布局，谁说后台都很丑
* 安全--每一个字段都有严格的前后端验证
* 一键安装，免去sql文件夹的导入
* 权限--自带后台用户权限
    *  用户管理
    *  节点管理
    *  角色授权
* 导航--前台导航管理




## 安装步骤（按照步骤来）：
1. 设置域名到根目录
2. Linux环境下runtime文件夹给予777权限
3. 访问后台是在域名加admin，例如http://www.lotusadmin.top/admin
 


##有问题反馈
在使用中有任何问题，欢迎反馈给我，可以用以下联系方式跟我交流

* 官方交流群 606645328
* 邮件 whndeweilai@163.com
* 个人QQ: 610176732
* weibo: [@晓野兔子](http://weibo.com/wenhainan)


##部署Linux问题
 * 部署Linux系统的LNMP(apache没有问题)需要重写伪静态规则，请按照我的博客教程修改nginx配置 http://www.cnblogs.com/wenhainan/p/7300352.html


##捐助开发者
在兴趣的驱动下,写一个`新手免费学习`的东西，有欣喜，也还有汗水，希望你喜欢我的作品，同时也能支持一下。

 
##商业授权协议： 如需商用请联系官方群群主，统一定价：49元。

谢谢！我也不会因为49元去告你的，但请接收我的鄙视。


搞定收工咯！

##感激
感谢以下的项目,排名不分先后

* [layui](http://www.layui.com/) 
* [thinkphp](http://www.thinkphp.cn/)


##微信捐赠作者，支持继续开发
 
<img src="./public/pic/wechat.jpg" style="float: left" alt="..." width="100px">

##支付宝捐赠作者，支持继续开发

<img src="./public/pic/alipay.jpg" style="float: left" alt="..." width="100px">

##关于作者

```javascript
  var wenhainan = {
    nickName  : "闻海南",
    site : "http://www.cnblogs.com/wenhainan/"
  }